package com.example.nila;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Locale;

public class GetCovid extends AppCompatActivity {
    private static HttpURLConnection connection;
    private StringBuffer responseContent = new StringBuffer();
    private String responseBody;
    Button btn;
    EditText et;
    TextView tv;
    LinearLayout linearLayout;
    LayoutInflater layoutInflater;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_get_covid);

        linearLayout = findViewById(R.id.lin);
        layoutInflater = LayoutInflater.from(this);

        et = (EditText)findViewById(R.id.state);
        btn = (Button)findViewById(R.id.button3);
        tv = (TextView)findViewById(R.id.textView7);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Thread thread = new Thread(){
                    public void run(){ covid();
                    }
                };
                thread.start();
                try {
                    thread.join();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                String state = et.getText().toString().trim().toUpperCase();
                parse(state);
            }
        });
    }

    public void covid() {
        BufferedReader reader;
        String line;
        try {
            URL url = new URL("https://localcoviddata.com/covid19/v1/cases/jhu?daysInPast=4&country=IND");
            connection = (HttpURLConnection) url.openConnection();

            // request setup
            connection.setRequestMethod("GET");
            connection.setConnectTimeout(5000);
            connection.setReadTimeout(5000);

            // status = 200 if connection established
            int status = connection.getResponseCode();

            if (status > 299) {
                System.out.println("Error in connection");
            } else {
                reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                while ((line = reader.readLine()) != null) {
                    responseContent.append(line);
                }
                reader.close();

            }
            responseBody = responseContent.toString();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            connection.disconnect();
        }
    }

    public void parse(String state) {

        try {
            JSONObject album = new JSONObject(responseBody);

            JSONObject temp1 = album.getJSONObject("historicData");
            JSONArray temp2 = temp1.getJSONArray("historicData");
            boolean flag = false;

            int n = temp2.length();
            linearLayout.removeAllViews();
            for(int i=0; i<n; i++) {
                JSONObject temp3 = temp2.getJSONObject(i);
                String name = temp3.getString("provinceStateName").toUpperCase();
                if(name.equals(state)){
                    flag = true;
                    tv.setText(state);
                    String active_case = temp3.getString("peoplePositiveCasesCt");
                    String dead_case = temp3.getString("deathCt");
                    String date = temp3.getString("date");

                    View view1 = layoutInflater.inflate(R.layout.covid_head, linearLayout, false);
                    TextView t = view1.findViewById(R.id.tv_head);
                    String[] d;
                    try{
                        d = date.split("-");
                        date = "Date: "+d[2]+"-"+d[1]+"  ("+d[0]+")";
                        t.setText(date);
                    }catch(Exception e){}
                    linearLayout.addView(view1);

                    View view = layoutInflater.inflate(R.layout.covid_tail,linearLayout,false);
                    TextView tv1 = view.findViewById(R.id.tv_tail1);
                    tv1.setText("Active count: "+active_case);
                    TextView tv2 = view.findViewById(R.id.tv_tail2);
                    tv2.setText("dead count: "+dead_case);

                    linearLayout.addView(view);

                }
            }
            if(flag == false){
                tv.setText("-----");
            }

        } catch (Exception e) {
        }
    }
}