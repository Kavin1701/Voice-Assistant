package com.example.nila;

import static android.Manifest.permission.READ_EXTERNAL_STORAGE;
import static android.Manifest.permission.RECORD_AUDIO;
import static android.Manifest.permission.WRITE_EXTERNAL_STORAGE;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraManager;
import android.os.Build;
import android.os.Bundle;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import com.bumptech.glide.Glide;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.Calendar;

public class MainActivity extends AppCompatActivity {
    public TextToSpeech textToSpeech;
    public Intent intent;
    public SpeechRecognizer speechRecognizer;
    public ArrayList<String> matches,matches_partial;
    public boolean flagOnBegin = true;
    public String beginText;

    public EditText screen;
    public ImageButton button;
    public TextView textView;

    private CameraManager cameraManager;
    private String getCameraID;
    JSONObject model;
    String[] class_labels;
    String[] columns;
    JSONObject label_prob;

    String[] matches_org;
    TextToSpeech tts;

    ImageView snow;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initialize();
        getUserPermission();
        readModel();


        snow = (ImageView)findViewById(R.id.imageView8);


        btn_stop();
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    startListening();
                }
            }
        });

        tts = new TextToSpeech(getApplicationContext(), new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int i) {
                begin();
            }
        }, "com.google.android.tts");
    }

    public void begin(){
        if(flagOnBegin) {
            tts.speak("How can I help you", TextToSpeech.QUEUE_FLUSH, null, null);
            try {
                Thread.sleep(2500);
            }catch (InterruptedException e){
                e.printStackTrace();
            }
        }
        flagOnBegin = false;
    }

    public void btn_listen(){
        Glide.with(this).load(R.drawable.x9).into(button);
        Glide.with(this).load(R.drawable.p3).into(snow);
    }

    public void btn_stop(){
        Glide.with(this).load(R.drawable.voicewave).into(button);
        Glide.with(this).load(R.drawable.h2).into(snow);
    }

    private void initialize(){
        // text to speech initialized with override methods
        textToSpeech = new TextToSpeech(this, new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int i) { }});

        // intent for calling the recognizer event
        intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS,true);
        intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "Say the magic word");

        // text to speech recognizer initialized with override methods
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this);
        speechRecognizer.setRecognitionListener(new RecognitionListener() {
            @Override
            public void onReadyForSpeech(Bundle bundle) {}

            @Override
            public void onBeginningOfSpeech() {}

            @Override
            public void onRmsChanged(float v) {}

            @Override
            public void onBufferReceived(byte[] bytes) {}

            @Override
            public void onEndOfSpeech() {
                btn_stop();
            }

            @Override
            public void onError(int i) {}

            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onResults(Bundle bundle) {
                matches = bundle.getStringArrayList(speechRecognizer.RESULTS_RECOGNITION);
                if(matches != null){
                    try {
                        Thread.sleep(1200);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    processSpeech();
                    screen.setText("");
                }
                else{

                }
            }

            @Override
            public void onPartialResults(Bundle bundle_partial) {
                matches_partial = bundle_partial.getStringArrayList(speechRecognizer.RESULTS_RECOGNITION);
                String t = matches_partial.toString();
                screen.setText(t.substring(1,t.length()-1));
            }

            @Override
            public void onEvent(int i, Bundle bundle) {}
        });

        beginText = "How can I help You?";

        screen = (EditText)findViewById(R.id.screen);

        button = (ImageButton)findViewById(R.id.button);

        cameraManager = (CameraManager) getSystemService(Context.CAMERA_SERVICE);

        try{
            getCameraID = cameraManager.getCameraIdList()[0];
        }
        catch(CameraAccessException e){
            e.printStackTrace();
        }
    }
    private void getUserPermission(){
        // request permission's
        ActivityCompat.requestPermissions(this, new String[]{RECORD_AUDIO, WRITE_EXTERNAL_STORAGE, READ_EXTERNAL_STORAGE, Manifest.permission.READ_CONTACTS,Manifest.permission.WRITE_CONTACTS,Manifest.permission.WRITE_CALENDAR,Manifest.permission.READ_CALENDAR,Manifest.permission.INTERNET,Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION,Manifest.permission.CALL_PHONE}, PackageManager.PERMISSION_GRANTED);
    }
    private void readModel(){
        String codex="";
        try{
            InputStream inputStream = getAssets().open("model.txt");
            int size = inputStream.available();
            byte[] buffer = new byte[size];
            inputStream.read(buffer);
            codex = new String(buffer);
        }catch(Exception io){io.printStackTrace();}

        try {
            JSONArray ar1, ar2;
            JSONObject temp = new JSONObject(codex);

            model = temp.getJSONObject("model");
            label_prob = temp.getJSONObject("label_prob");
            ar1 = temp.getJSONArray("columns");
            ar2 = temp.getJSONArray("labels");

            int n1 = ar1.length();
            int n2 = ar2.length();
            columns = new String[n1];
            class_labels = new String[n2];
            for(int i=0; i<n1; i++){
                columns[i] = ar1.getString(i);
            }
            for(int i=0; i<n2; i++){
                class_labels[i] = ar2.getString(i);
            }
        }catch(Exception e){e.printStackTrace();}
    }

    private void startListening(){
        btn_listen();
        speechRecognizer.startListening(intent);
    }
    @RequiresApi(api = Build.VERSION_CODES.M)
    private void processSpeech(){
        String funcName = null;
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.N) {
            funcName = findFunction();
        }
        if(funcName.equals("func1")){
            Intent i = new Intent(MainActivity.this, CreateContact.class);
            startActivity(i);
        }
        else if(funcName.equals("func2")){
            Intent i = new Intent(MainActivity.this, SearchForContacts.class);
            startActivity(i);
        }
        else if(funcName.equals("func3")){
            Intent i = new Intent(MainActivity.this, SearchForContact.class);
            startActivity(i);
        }
        else if(funcName.equals("func4")){
            Intent i = new Intent(MainActivity.this, GetEventOn.class);
            i.putExtra("key",String.valueOf(0));
            startActivity(i);
        }
        else if(funcName.equals("func5")){
            Intent i = new Intent(MainActivity.this, GetEventOn.class);
            i.putExtra("key",String.valueOf(1));
            startActivity(i);
        }
        else if(funcName.equals("func6")){
            Intent i = new Intent(MainActivity.this, GetEventOn.class);
            i.putExtra("key",String.valueOf(-1));
            startActivity(i);
        }
        else if(funcName.equals("func7")){
            Intent i = new Intent(MainActivity.this, GetEventForWeek.class);
            i.putExtra("key",String.valueOf(0));
            startActivity(i);
        }
        else if(funcName.equals("func8")){
            Intent i = new Intent(MainActivity.this, GetEventForWeek.class);
            i.putExtra("key",String.valueOf(1));
            startActivity(i);
        }
        else if(funcName.equals("func9")){
            Intent i = new Intent(MainActivity.this, GetEventForWeek.class);
            i.putExtra("key",String.valueOf(- 1));
            startActivity(i);
        }
        else if(funcName.equals("func10")){
            Intent i = new Intent(MainActivity.this, GetWeather.class);
            startActivity(i);
        }
        else if(funcName.equals("func11")){
            Intent i = new Intent(MainActivity.this, GetCovid.class);
            startActivity(i);
        }
        else if(funcName.equals("func12")){
            Intent i = new Intent(MainActivity.this, About.class);
            startActivity(i);
        }
        else if(funcName.equals("func13")){
            //age
        }
        else if(funcName.equals("func14")){
            // date and time
        }
        else if(funcName.equals("func15")){
            TorchOn();
        }
        else if(funcName.equals("func16")){
            TorchOff();
        }
        else if(funcName.equals("func17")){
            addEvent();
        }

    }

    private boolean check(String key){
        for(String s: matches_org){
            if(s.equals(key)){
                return true;
            }
        }
        return false;
    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    @SuppressLint("NewApi")
    private String findFunction(){

        String str = matches.toString();
        str = str.substring(1,str.length()-1);
        str = str.toUpperCase();

        matches_org = str.split(" ");

        for(String s: matches_org) {
            System.out.println("-"+s+"-");
        }

        double predict;
        double max_predict = -1;
        String predict_label = "";

        try {
            for (String label : class_labels) {
                JSONObject labelObj = model.getJSONObject(label);
                predict = label_prob.getDouble(label);

                for(String key:columns){
                    if(check(key)){
                        predict *= labelObj.getDouble(key);
                    }
                    else{
                        predict *= (1 - labelObj.getDouble(key));
                    }
                }

                if(predict > max_predict){
                    max_predict = predict;
                    predict_label = label;
                }
            }
        }catch(Exception e){}

        return predict_label;
    }

    public void addEvent(){
        Calendar cal = Calendar.getInstance();
        Intent intent = new Intent(Intent.ACTION_EDIT);
        intent.setType("vnd.android.cursor.item/event");
        intent.putExtra("beginTime", cal.getTimeInMillis());
        intent.putExtra("allDay", false);
        intent.putExtra("rrule", "FREQ=YEARLY");
        intent.putExtra("title", "Give your title");
        startActivity(intent);
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    public void TorchOn(){
        try{
            cameraManager.setTorchMode(getCameraID,true);

        }catch(CameraAccessException e){
            e.printStackTrace();
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    public void TorchOff(){
        try{
            cameraManager.setTorchMode(getCameraID, false);

        }catch(CameraAccessException e){
            e.printStackTrace();
        }
    }
}