package com.example.nila;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Looper;
import android.provider.Settings;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;

import org.json.JSONArray;
import org.json.JSONObject;
import org.w3c.dom.Text;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.List;

public class GetWeather extends AppCompatActivity {
    private static HttpURLConnection connection;
    String responseBody;
    EditText city;
    Button search;
    ImageView climate;
    TextView lon, lat, sunset, sunrise, pressure, humidity, wind_speed,temp,tim, dat,desc;

    public String lon1, lat1, temperature1, pressure1, humidity1, wind_speed1, description1, icon1, sunrise1, sunset1, time1, date1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_get_weather);

        initialize();
        setText();

        search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Thread thread = new Thread(){
                    public void run(){
                        weather();
                        parse();
                    }
                };
                thread.start();
                try {
                    thread.join();
                    setDisplay();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public void initialize(){
        city = (EditText)findViewById(R.id.city);
        search = (Button)findViewById(R.id.search);
        climate = (ImageView)findViewById(R.id.climate);

        lat = (TextView)findViewById(R.id.lat);
        lon = (TextView)findViewById(R.id.lon);
        sunrise = (TextView)findViewById(R.id.sunrise);
        sunset = (TextView)findViewById(R.id.sunset);
        pressure = (TextView)findViewById(R.id.pressure);
        humidity = (TextView)findViewById(R.id.humidity);
        wind_speed = (TextView)findViewById(R.id.windspeed);
        temp = (TextView)findViewById(R.id.temp);
        tim = (TextView)findViewById(R.id.time);
        dat = (TextView)findViewById(R.id.date);
        desc = (TextView)findViewById(R.id.desc);
    }

    public void setText(){
        lon.setText("---");
        lat.setText("---");
        sunset.setText("---");
        sunrise.setText("---");
        pressure.setText("---");
        humidity.setText("---");
        wind_speed.setText("---");
        temp.setText("---");
        tim.setText("---");
        dat.setText("---");
        desc.setText("---");
    }

    public void setDisplay(){
        if(responseBody.equals("")){
            setText();
        }
        else{
            lon.setText(lon1);
            lat.setText(lat1);
            sunset.setText(sunset1);
            sunrise.setText(sunrise1);
            pressure.setText(pressure1);
            humidity.setText(humidity1);
            wind_speed.setText(wind_speed1);
            temp.setText(temperature1);
            tim.setText(time1);
            dat.setText(date1);
            desc.setText(description1);
            System.out.println(icon1);

            
            new DownloadImageFromInternet(climate).execute("https://openweathermap.org/img/w/10d.png");

        }
    }

    private class DownloadImageFromInternet extends AsyncTask<String, Void, Bitmap> {
        ImageView imageView;
        public DownloadImageFromInternet(ImageView imageView) {
            this.imageView=imageView;

        }
        protected Bitmap doInBackground(String... urls) {
            String imageURL=urls[0];
            Bitmap bimage=null;
            try {
                InputStream in=new java.net.URL(imageURL).openStream();
                bimage=BitmapFactory.decodeStream(in);
            } catch (Exception e) {
                Log.e("Error Message", e.getMessage());
                e.printStackTrace();
            }
            return bimage;
        }
        protected void onPostExecute(Bitmap result) {
            imageView.setImageBitmap(result);
        }
    }

    public void weather(){
        StringBuffer responseContent = new StringBuffer();
        String str = city.getText().toString();
        str = str.trim();
        BufferedReader reader;
        String line;
        try{
            URL url = new URL("https://api.openweathermap.org/data/2.5/weather?q="+str+"&units=metric&appid=90d47fb014a5debcce007f48f6aa0daa");
            connection = (HttpURLConnection) url.openConnection();

            // request setup
            connection.setRequestMethod("GET");
            connection.setConnectTimeout(5000);
            connection.setReadTimeout(5000);

            // status = 200 if connection established
            int status = connection.getResponseCode();

            if(status > 299){
                System.out.println("Error in connection");
            }

            else{
                reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                while((line = reader.readLine())!= null){
                    responseContent.append(line);
                }
                reader.close();

            }
            responseBody = responseContent.toString();
        }catch(Exception e){
            responseBody = "";
            e.printStackTrace();
        }finally{connection.disconnect();}
    }

    public void parse(){
        if(responseBody.equals(""))
            return;
        else {
            try {
                JSONObject album = new JSONObject(responseBody);

                JSONObject temp1 = album.getJSONObject("coord");
                lon1 = String.valueOf(temp1.getDouble("lon"));
                lat1 = String.valueOf(temp1.getDouble("lat"));

                JSONArray temp2 = album.getJSONArray("weather");
                temp1 = temp2.getJSONObject(0);
                description1 = temp1.getString("description");
                icon1 = temp1.getString("icon");

                temp1 = album.getJSONObject("main");
                temperature1 = String.valueOf((int)temp1.getDouble("feels_like"))+"°C";
                pressure1 = String.valueOf(temp1.getDouble("pressure"));
                humidity1 = String.valueOf(temp1.getDouble("humidity"));

                temp1 = album.getJSONObject("wind");
                wind_speed1 = String.valueOf(temp1.getDouble("speed"));

                Long l1 = album.getLong("dt");

                temp1 = album.getJSONObject("sys");
                Long l2 = temp1.getLong("sunrise");
                Long l3 = temp1.getLong("sunset");

                java.util.Date time = new java.util.Date(l1 * 1000);
                Format f = new SimpleDateFormat("HH:mm");
                time1 = f.format(time);

                Format f1 = new SimpleDateFormat("E, dd MMM");
                date1 = f1.format(time);

                time = new java.util.Date(l2 * 1000);
                sunrise1 = f.format(time);

                time = new java.util.Date(l3 * 1000);
                sunset1 =f.format(time);

            } catch (Exception e) {
                responseBody = "";
            }
        }
    }
}

