package com.example.nila;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.media.Image;
import android.net.Uri;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class SearchForContact extends AppCompatActivity {
    Button btn, btn_call;
    TextView up, down, search_name;
    ImageView imageView;
    String num="";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_for_contact);

        up = (TextView) findViewById(R.id.textView3);
        down = (TextView) findViewById(R.id.textView2);
        search_name = (TextView)findViewById(R.id.search_name);
        imageView = (ImageView) findViewById(R.id.imageView2);
        btn = (Button)findViewById(R.id.search_contact);
        btn_call = (Button)findViewById(R.id.button2);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                searchForContact(search_name.getText().toString());
            }
        });

        btn_call.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(num != "") {
                    Intent callIntent = new Intent(Intent.ACTION_CALL);
                    callIntent.setData(Uri.parse("tel:" + num));
                    startActivity(callIntent);
                }
            }
        });
    }
    public void searchForContact(String s){
        s = s.trim().toUpperCase();

        Uri uri = ContactsContract.CommonDataKinds.Phone.CONTENT_URI;
        String[] projection = {ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER,ContactsContract.CommonDataKinds.Phone.PHOTO_URI,ContactsContract.Contacts._ID};
        String selection = null;
        String[] selectionArgs = null;
        String sortOrder = null;
        ContentResolver resolver = getContentResolver();
        Cursor cursor = resolver.query(uri, projection, selection, selectionArgs, sortOrder);

        String imageUri=null;
        String disp="";
        int k=0;
        while (cursor.moveToNext()) {
            String name = cursor.getString(cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME));

            if(s.equals(name.toUpperCase())) {
                String n = cursor.getString(cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER));
                String i = cursor.getString(cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.PHOTO_URI));
                String id = cursor.getString(cursor.getColumnIndex(ContactsContract.Contacts._ID));

                if(n != null){
                    if(k==0) {
                        disp = disp + "\n"+n;
                        k++;
                        num = n;
                    }
                    else {
                        disp = disp + "\n"+n;
                    }
                }

                if(i != null && imageUri == null)
                    imageUri = i;

            }
        }

        up = (TextView) findViewById(R.id.textView3);
        down = (TextView) findViewById(R.id.textView2);


        if (disp.equals("")) {
            up.setText("Not available");
            down.setText("");
            num = "";
            imageView.setImageResource(R.drawable.contact2);
        }
        else {
            if (imageUri != null) {
                imageView = (ImageView) findViewById(R.id.imageView2);
                imageView.setImageURI(Uri.parse(imageUri));
            }
            else{
                imageView.setImageResource(R.drawable.contact2);
            }
            up.setText("Available");
            down.setText(s + "\n" + disp);
        }
    }
}