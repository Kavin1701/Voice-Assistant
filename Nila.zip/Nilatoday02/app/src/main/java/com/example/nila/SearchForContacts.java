package com.example.nila;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

public class SearchForContacts extends AppCompatActivity {
    LinearLayout linearLayout;
    LayoutInflater layoutInflater;
    EditText search_letter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_for_contacts);

        search_letter = (EditText)findViewById(R.id.search_letter);
        linearLayout = findViewById(R.id.linear);
        layoutInflater = LayoutInflater.from(this);

        display("");

        search_letter.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String str1 = String.valueOf(s);
                str1 = str1.trim().toUpperCase();
                display(str1);
            }

            @Override
            public void afterTextChanged(Editable s) { }
        });
    }

    public void display(String str1){
        Uri uri = ContactsContract.CommonDataKinds.Phone.CONTENT_URI;
        String[] projection = {ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER,ContactsContract.CommonDataKinds.Phone.PHOTO_URI};
        String selection = null;
        String[] selectionArgs = null;
        String sortOrder = null;
        ContentResolver resolver = getContentResolver();
        Cursor cursor = resolver.query(uri, projection, selection, selectionArgs, sortOrder);

        String contacts[] = new String[cursor.getCount()];
        int i = -1;
        while (cursor.moveToNext()) {
            String name = cursor.getString(cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME));

            if(name.length() >= str1.length()) {
                if (name.toUpperCase().substring(0, str1.length()).equals(str1)) {
                    String number = cursor.getString(cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER));
                    String imageUri = cursor.getString(cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.PHOTO_URI));

                    i++;
                    contacts[i] = name + "-" + number + "-" + imageUri;
                }
            }
        }


        linearLayout.removeAllViews();
        for(String str:contacts){
            if(str==null)
                break;
            String[] sArr = str.split("-");
            String name = sArr[0];
            String number = sArr[1];
            String image = sArr[2];

            System.out.println(str);
            View view = layoutInflater.inflate(R.layout.contact_row,linearLayout,false);
            TextView tv1 = view.findViewById(R.id.name);
            tv1.setText(name);
            TextView tv2 = view.findViewById(R.id.number);
            tv2.setText(number);

            linearLayout.addView(view);
        }
    }

}