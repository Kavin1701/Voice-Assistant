package com.example.nila;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentUris;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.CalendarContract;
import android.text.format.Time;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;

public class GetEventForWeek extends AppCompatActivity implements AdapterView.OnItemSelectedListener {
    LinearLayout linearLayout;
    LayoutInflater layoutInflater;
    private Spinner spinner;
    private static final String[] paths = {"This Week", "Next Week", "Last Week"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_get_event_for_week);

        Intent intent = getIntent();
        int check = Integer.parseInt(intent.getStringExtra("key"));

        spinner = (Spinner)findViewById(R.id.spinner);
        ArrayAdapter<String>adapter = new ArrayAdapter<String>(GetEventForWeek.this,
                android.R.layout.simple_spinner_item,paths);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener(this);

        linearLayout = findViewById(R.id.linear);
        layoutInflater = LayoutInflater.from(this);

        if(check == 0){
            spinner.setSelection(0);
            getEventsOn(0);
        }
        else if(check == 1){
            spinner.setSelection(1);
            getEventsOn(1);
        }
        else if(check == -1){
            spinner.setSelection(2);
            getEventsOn(-1);
        }
    }

    public static Calendar getWeekStartDate() {
        Calendar calendar = Calendar.getInstance();
        while (calendar.get(Calendar.DAY_OF_WEEK) != Calendar.MONDAY) {
            calendar.add(Calendar.DATE, -1);
        }
        return calendar;
    }

    private void getEventsOn(int x) {
        Time today = new Time(Time.getCurrentTimezone());
        today.setToNow();
        int year = today.year;

        Calendar c = getWeekStartDate();
        if(x == 1)
            c.add(Calendar.DATE,7);
        else if(x == -1)
            c.add(Calendar.DATE,-7);

        int monthDay = c.get(Calendar.DAY_OF_MONTH);
        int month = c.get(Calendar.MONTH);
        System.out.println(monthDay+" - "+month);

        linearLayout.removeAllViews();
        for(int i=1;i<=7;i++) {
            View view1 = layoutInflater.inflate(R.layout.week_event_row_head,linearLayout,false);
            TextView t = view1.findViewById(R.id.head_txt);
            t.setText("Day : "+i);

            linearLayout.addView(view1);

            final String[] INSTANCE_PROJECTION = new String[]{
                    CalendarContract.Instances.EVENT_ID,
                    CalendarContract.Instances.BEGIN,
                    CalendarContract.Instances.END,
                    CalendarContract.Instances.TITLE,
                    CalendarContract.Instances.ORGANIZER,
                    CalendarContract.Instances.CALENDAR_DISPLAY_NAME
            };

            // The indices for the projection array above.
            final int PROJECTION_ID_INDEX = 0;
            final int PROJECTION_BEGIN_INDEX = 1;
            final int PROJECTION_END_INDEX = 2;
            final int PROJECTION_TITLE_INDEX = 3;
            final int PROJECTION_ORGANIZER_INDEX = 4;
            final int PROJECTION_CALENDAR_NAME = 5;


            // Specify the date range you want to search for recurring event instances
            Calendar beginTime = Calendar.getInstance();
            beginTime.set(year, month, monthDay, 0, 0);
            long startMillis = beginTime.getTimeInMillis();
            Calendar endTime = Calendar.getInstance();
            endTime.set(year, month, monthDay, 23, 0);
            long endMillis = endTime.getTimeInMillis();

            // Construct the query with the desired date range.
            Uri.Builder builder = CalendarContract.Instances.CONTENT_URI.buildUpon();
            ContentUris.appendId(builder, startMillis);
            ContentUris.appendId(builder, endMillis);

            // Submit the query
            Cursor cur = getContentResolver().query(builder.build(), INSTANCE_PROJECTION, null, null, null);

            while (cur.moveToNext()) {

                // Get the field values
                long eventID = cur.getLong(PROJECTION_ID_INDEX);
                long beginVal = cur.getLong(PROJECTION_BEGIN_INDEX);
                long endVal = cur.getLong(PROJECTION_END_INDEX);
                String title = cur.getString(PROJECTION_TITLE_INDEX);
                String organizer = cur.getString(PROJECTION_ORGANIZER_INDEX);
                String calendar_name = cur.getString(PROJECTION_CALENDAR_NAME);

                Calendar calendar1 = Calendar.getInstance();
                calendar1.setTimeInMillis(beginVal);
                DateFormat formatter1 = new SimpleDateFormat("dd/MM  hh:mm");
                String start_time = formatter1.format(calendar1.getTime());

                calendar1.setTimeInMillis(endVal);
                DateFormat formatter2 = new SimpleDateFormat("hh:mm");
                String end_time = formatter2.format(calendar1.getTime());

                System.out.println("Row :" + eventID + " - " + start_time + " - " + end_time + " - " + title + " - " + organizer + " - " + calendar_name);

                String timing = start_time+" - "+end_time;
                View view = layoutInflater.inflate(R.layout.week_event_row_tail,linearLayout,false);
                TextView tv1 = view.findViewById(R.id.tvt1);
                tv1.setText(title);
                TextView tv2 = view.findViewById(R.id.tvt2);
                tv2.setText(timing+" - "+calendar_name);

                linearLayout.addView(view);

            }
            c.add(Calendar.DATE, 1);
            monthDay = c.get(Calendar.DAY_OF_MONTH);
            month = c.get(Calendar.MONTH);
            System.out.println(monthDay + " - " + month);
        }
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        switch(position){
            case 0:
                getEventsOn(0);
                break;

            case 1:
                getEventsOn(1);
                break;

            case 2:
                getEventsOn(-1);
                break;
        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}